#include "Arduino.h"
#include "TriumfMQTT.h"

int post2MQTT(PubSubClient &m_client, std::string topic, std::string toPost, 
              const char *username, const char *password) {

  // Connect: try connecting 5 times with delays
  for (int i = 0; i < 5; i++) {
    if (m_client.connect("canary0", username, password)) {
      break;
    }
    else {
    // print why the connection failed
      Serial.print("MQTT connect status: ");
      switch (m_client.state()){
        case -4:
          Serial.println("timeout");
          break;
        case -3:
          Serial.println("lost");
          break;
        case -2:
          Serial.println("failed");
          break;
        case -1:
          Serial.println("disconnected");
          break;
        case 0:
          Serial.println("connected");
          break;
        case 1:
          Serial.println("bad protocol");
          break;
        case 2:
          Serial.println("bad client ID");
          break;
        case 3:
          Serial.println("unavailable");
          break;
        case 4:
          Serial.println("bad credentials");
          break;
        case 5:
          Serial.println("unauthorized");
          break;
        default:
          Serial.println("unknown");
          break;
      }
      delay(1000);
    }
  }

  // Post the json string
  if (m_client.connected()) {
    //call the loop continuously to establish connection to the server
    m_client.loop();
    m_client.publish(topic.c_str(), toPost.c_str());
    Serial.print("Posted: ");
    Serial.print(toPost.c_str());
    Serial.print(" with topic ");
    Serial.println(topic.c_str());
    m_client.disconnect();
  }
  return 0;
}

void addItem(std::string &toPost, const std::string name, const float value, const int decimalPlaces) {
  if (toPost.length() == 0) // New string; add opening brace
    toPost = "{";
  if (name.length() == 0) {
    toPost += "}"; // Calling with a blank name terminates the string
    return;
  }

  if (toPost.length() > 1) // Second or later item, separate with comma
    toPost += ", ";

  toPost += '"' + name + "\": ";
  String x = ((isnan(value) || isinf(value))? "null": String(value, decimalPlaces));
  toPost += x.c_str();
}
