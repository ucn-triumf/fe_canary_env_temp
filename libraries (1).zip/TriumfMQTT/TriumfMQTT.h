#ifndef TRIUMFMQTT_H
#define TRIUMFMQTT_H

/*
 *    Wrapper to make it easy to use the MQTT library in TRIUMF MSR room
 *    Could not get connect to work when PubSubClient was stored in a class. So made a classless version.
 */

#include "Arduino.h"
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <string>

#define DEFAULT_MQTT_SERVER "142.90.151.4"
#define DEFAULT_MQTT_PORT 8883
#define DEFAULT_MQTT_TOPIC "msr"
#define DEFAULT_MQTT_USER "canary"
#define DEFAULT_MQTT_PASSWORD "measuretemp"

// Your code needs something like the following:
// #include "TriumfMQTT.h"
// ...
//   WiFiClient wiFiClient;
//   PubSubClient mqtt(DEFAULT_MQTT_SERVER, DEFAULT_MQTT_PORT, wiFiClient);

// Post a json string toPost with topic/clientID topic
int post2MQTT(PubSubClient &mqtt, std::string topic, std::string toPost, 
              const char *username = DEFAULT_MQTT_USER, const char *password = DEFAULT_MQTT_PASSWORD);

// Helper to build up a jason string. Adds start { to blank string; adds name, value pairs separated by ,
// Adds final } if name is blank.
void addItem(std::string &toPost, const std::string name, const float value = 0., const int decimalPlaces = 3);

#endif // TRIUMFMQTT_H