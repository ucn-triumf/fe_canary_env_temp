#ifndef TRIUMFWIFI_H
#define TRIUMFWIFI_H
/*
 *    Very simple library to connect WiFi to TRIUMF IoT (or over-ride default and connect elsewhere.
 *    Basically, saves copying and pasting code just to connect our canaries to WiFi.
 */
#include "Arduino.h"
#include <string>

// Easy connection:
  int connectWiFi(const char *ssid = "Heidi's fam", const char *passwd = "getOFFourw1f1!");
// Get MAC address in form 12345678ABCD, suitable for adding to topic string for MQTT
  std::string macAddress();
  
#endif // TRIUMFWIFI_H
