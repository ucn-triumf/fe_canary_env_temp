#include "ESP8266WiFi.h"
#include "TriumfWiFi.h"

extern "C" {
#include "user_interface.h"
#include "wpa2_enterprise.h"
#include "c_types.h"
}

// uint8_t target_esp_mac[6] = {0x24, 0x0a, 0xc4, 0x9a, 0x58, 0x28};

int connectWiFi(const char *ssid, const char *username, const char *password) {

  //https://github.com/esp8266/Arduino/issues/2702
  WiFi.disconnect();
  WiFi.persistent(false);  // Avoid wearing out the flash mem
  WiFi.mode(WIFI_STA);     // Only act as a station, not an Access Point AP

// ~~~~~~~~~~~~~~~~ from internet lol
  wifi_set_opmode(STATION_MODE);  // sus... maybe already done

  struct station_config wifi_config;

  memset(&wifi_config, 0, sizeof(wifi_config));
  strcpy((char*)wifi_config.ssid, ssid);
  strcpy((char*)wifi_config.password, password);

//  wifi_station_set_config(&wifi_config);
//  wifi_set_macaddr(STATION_IF,target_esp_mac);
  
  wifi_station_set_wpa2_enterprise_auth(1);

  // Clean up to be sure no old data is still inside
  wifi_station_clear_cert_key();
  wifi_station_clear_enterprise_ca_cert();
  wifi_station_clear_enterprise_identity();
  wifi_station_clear_enterprise_username();
  wifi_station_clear_enterprise_password();
  wifi_station_clear_enterprise_new_password();
  
  wifi_station_set_enterprise_identity((uint8*)username, strlen(username));
  wifi_station_set_enterprise_username((uint8*)username, strlen(username));
  wifi_station_set_enterprise_password((uint8*)password, strlen((char*)password));

  wifi_station_connect();
// ~~~~~~~~~~~~~~~~ ~~~~~~~~~~~~~~~~ 


//  WiFi.begin(ssid, password);
  Serial.print("WiFi connecting to ");
  Serial.println(ssid);

  // Wait for connection for up to 20 seconds
  for (int ii = 0; ii < 20; ii++){
    if (WiFi.status() == WL_CONNECTED) {
          Serial.print("Success; Wifi connected to ");
          Serial.print(ssid);
          Serial.print(". ");
          Serial.print("IP: ");
          Serial.print(WiFi.localIP());
          Serial.print(". MAC: ");
          Serial.println(macAddress().c_str());
      break;
    }
    else {
      Serial.print("status: ");
      switch (WiFi.status()){
        case 0:
          Serial.println("idle");
          break;
        case 1:
          Serial.println("no SSID");
          break;
        case 2:
          Serial.println("scan compl.");
          break;
        case 3:
          Serial.print("Success; Wifi connected to ");
          Serial.print(ssid);
          Serial.print(". IP: ");
          Serial.print(WiFi.localIP());
          Serial.print(". RSSI: ");
          Serial.println(WiFi.RSSI());
          break;
        case 4:
          Serial.println("connection failed");
          break;
        case 5:
          Serial.println("connection lost");
          break;
        case 6:
          Serial.println("disconnected");
          break;
        default:
          Serial.println("unknown");
          break;
      }
    }
    //delay between trials in ms
    delay(1000);
  }

  if (WiFi.status() != WL_CONNECTED) {
    Serial.print("could not connect to ");
    Serial.print(ssid);
    Serial.print(" with MAC address ");
    Serial.println(macAddress().c_str());
    return 0; // Fail
  }
  return 1; // Success
}

std::string macAddress() {
  char clientID[20];
  byte mac[6] = {0, 0, 0, 0, 0, 0};
  WiFi.macAddress(mac);
  for (int m = 0; m < 6; ++m) {
    sprintf(&clientID[2 * m], "%02X", mac[m]);
  }
  return std::string(clientID);
}
